﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program8
{
    internal class Program
    {
        static void Main()

        {
            Console.WriteLine("enter the number");
            int n = int.Parse(Console.ReadLine());
            int fact = 1;
            for (int i=n;i>=1;i--)
            {
                fact = fact * 1;

            }
            Console.WriteLine("factorial=" + fact);
        }
    }
}
