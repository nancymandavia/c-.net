﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program17
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("input:");
            int num = int.Parse(Console.ReadLine());
            int original = num;
            int sum = 0;
            int digits = num.ToString().Length;
            while (num > 0)
            {
                int digit = num % 10;
                sum += (int)Math.Pow(digits, digits);
                num /= 10;

            }
            if (sum == original)
                Console.WriteLine("it is armstrong");
            else
                Console.WriteLine("it is not armstrong ");



        }
    }
}
