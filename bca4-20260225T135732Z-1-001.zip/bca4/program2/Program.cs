﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program2
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("enter the value of a ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("enter the value of b");
            int b = int.Parse(Console.ReadLine());
            int c = a + b;
            int x = a - b;
            int y = a / b;
            int z = a % b;
            int t = a * b;
            Console.WriteLine("addition" + c);
            Console.WriteLine("subtraction" + x);
            Console.WriteLine("division"+y);
            Console.WriteLine("modulas" + z);
            Console.WriteLine("multiplication" + t);
                




        }
    }
}
