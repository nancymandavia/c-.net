﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extra_program
{
    internal class circle

    {
        int r;
        double area;

        public void getsdata()
        {
            Console.WriteLine("enter radious");
            r = int.Parse(Console.ReadLine());
        }

        public void calculate()
        {
            area = 3.14 * r * r;
        }

        public void display()
        {
            Console.WriteLine("area=" + area);

        }
    }
}
