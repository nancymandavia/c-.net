﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace program3
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("enter the value of amount");
            double value = double.Parse(Console.ReadLine());
            Console.WriteLine("enter the value of rate");
            double rate = double.Parse(Console.ReadLine());
            Console.WriteLine("enter the years");
            double years = double.Parse(Console.ReadLine());
            double si = (value * rate * years) / 100;
            Console.WriteLine("simple interest" + si);
        }
    }
}
