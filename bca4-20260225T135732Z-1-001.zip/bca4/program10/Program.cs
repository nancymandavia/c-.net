﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program10
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("enter the number");
            int n = int.Parse(Console.ReadLine());
            int m,i,flag;
            for(i =n; i<=n-1; i++)
            {
                m = n % 1;
                if(m==0)
                {
                    Console.WriteLine("not eligible no.");
                     flag = 1;
                        break;
                }
            }
            if(flag==0)
            {
                Console.WriteLine("eligible no.");
            }
        }
        
        }
    }

