﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program7
{
    internal class Program
    {
        static void Main()
        {
            console.writeline("enter the age");
            if(Age<12)
            {
             consle.writeline("kid");
            }
    else if(age>=12 && age<=17)
    {
        Console.WriteLine("teenager");
    }
    else if(age>=18 && age)
    {
    console.writeline("senior");
        }
    }
}
